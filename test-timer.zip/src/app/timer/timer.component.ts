import { Component, OnInit } from '@angular/core';
import { TimerObservable } from 'rxjs/observable/TimerObservable';
import * as Rx from 'rxjs/Rx';


@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {
  hours: number;
  minutes: number;
  seconds: number;
  timerSub;
  constructor() {

  }

  ngOnInit() {
  }
  start() {
    if (this.timerSub) {
      this.timerSub.unsubscribe();
      this.timerSub = null;
    } else {
      this.initiate();
    }
  }
  wait() {
    const button = document.querySelector('.btn');
    const clickObs = Rx.Observable.fromEvent(button, 'click');
    const doubleClicks = clickObs
    .buffer(clickObs.debounceTime(300))
      .map(clicksArr => clicksArr.length)
      .filter(clicksArr => clicksArr === 2)
      .subscribe(_ => {
        if (this.timerSub) {
          this.timerSub.unsubscribe();
          this.timerSub = null;
        }
      });

  }

  reset() {
    if (this.timerSub) {
      this.timerSub.unsubscribe();
      this.timerSub = null;
    }
    this.hours = 0;
    this.seconds = 0;
    this.minutes = 0;
  }
  initiate() {
    const timer = TimerObservable.create(0, 1000);
    this.timerSub = timer.subscribe(t => {
      this.seconds = t % 60;
      this.minutes = Math.floor(t / 60) % 60;
      this.hours = Math.floor(t / 3600) % 60;
    });
  }

}
